
/**
 * Una rueda de la maquina tragamonedas.
 * La rueda no sabe de la lista de simbolos de la maquina: solo recuerda
 * el indice del simbolo que esta mostrando y se dibuja a si misma.
 *
 * @author Oscar Carvajal
 * @author Wilmer Largo
 * @version 23/08/2026
 */
public class Wheel{

 
    private int current;
    private int xPosition;
    private Rectangle frame;
    private Rectangle display;
    private boolean visible;
 
    /**
     * Crea una rueda sin simbolo visible ubicada en la posicion indicada.
     * la rueda nace invisible.
     * @param x coordenada horizontal donde se dibuja la rueda
     * @param y coordenada vertical donde se dibuja la rueda
     */
    public Wheel(int x, int y) {
    }
 
    /**
     * Consulta el indice del simbolo que la rueda esta mostrando.
     * @return indice del simbolo visible o -1 si no muestra ninguno simbolo
     */
    public int getCurrent() {
        return -1;
    }
 
    /**
     * Dice directamente el indice del simbolo que debe mostrar la rueda
     * @param index indice del simbolo dentro de la lista de la maquina
     */
    public void setCurrent(int index) {
    }
 
    /**
     * Avanza la rueda al siguiente simbolo y vuelve al primero
     * cuando se llega al final.
     * @param total cantidad de simbolos que tiene la maquina
     */
    public void next(int total) {
    }
 
    /**
     * Pinta la rueda con el color del simbolo que esta mostrando.
     * @param color nombre CSS del color a mostrar
     */
    public void refresh(String color) {
    }
 
    /**
     * Reubica la rueda y sus figuras en la coordenada horizontal indicada.
     * @param x nueva coordenada horizontal
     */
    public void moveTo(int x) {
    }
 
    /**
     * Hace visible la rueda.
     */
    public void makeVisible() {
    }
 
    /**
     * Hace invisible la rueda.
     */
    public void makeInvisible() {
    }
}
